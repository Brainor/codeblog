#pragma once
#include "HTTPRequest.hpp"

//void httpPost(string body);
