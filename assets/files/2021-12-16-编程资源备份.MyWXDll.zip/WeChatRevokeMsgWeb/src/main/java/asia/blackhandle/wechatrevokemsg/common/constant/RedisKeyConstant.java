package asia.blackhandle.wechatrevokemsg.common.constant;

/**
 * RedisKeyConstant
 *
 * @author yongqi yang
 * @date 2021/11/30
 */
public class RedisKeyConstant {
    private RedisKeyConstant(){}

    public static final String REDIS_PREFIX = "RevokeMsg:";
}
