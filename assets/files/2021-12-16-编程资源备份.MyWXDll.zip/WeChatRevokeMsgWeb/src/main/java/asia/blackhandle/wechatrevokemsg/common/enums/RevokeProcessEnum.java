package asia.blackhandle.wechatrevokemsg.common.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * RevokeProcessEnum
 *
 * @author yongqi yang
 * @date 2021/11/30
 */
@Getter
@AllArgsConstructor
public enum RevokeProcessEnum {
    WECHAT(1, "微信PC"),
    QQ(2, "QQPC");

    private final Integer code;
    private final String name;


    /**
     * 获取枚举编码
     */
    public static RevokeProcessEnum getEnumByCode(Integer code) {
        for (RevokeProcessEnum revokeProcessEnum : RevokeProcessEnum.values()) {
            if (revokeProcessEnum.getCode().equals(code)) {
                return revokeProcessEnum;
            }
        }
        return null;
    }

    /**
     * 获取枚举名称
     */
    public static String getName(Integer code) {
        for (RevokeProcessEnum revokeProcessEnum : RevokeProcessEnum.values()) {
            if (revokeProcessEnum.getCode().equals(code)) {
                return revokeProcessEnum.getName();
            }
        }
        return null;
    }

}
