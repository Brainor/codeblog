package asia.blackhandle.wechatrevokemsg.common.constant;

/**
 * GlobalConstant
 *
 * @author yongqi yang
 * @date 2021/11/30
 */
public class GlobalConstant {

    private GlobalConstant(){}

    public static final Integer MESSAGE_LENGTH = 3;
}
