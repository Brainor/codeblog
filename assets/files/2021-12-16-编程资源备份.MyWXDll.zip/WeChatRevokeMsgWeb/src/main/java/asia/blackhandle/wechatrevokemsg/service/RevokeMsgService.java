package asia.blackhandle.wechatrevokemsg.service;

import asia.blackhandle.wechatrevokemsg.common.constant.GlobalConstant;
import asia.blackhandle.wechatrevokemsg.common.constant.IDWorker;
import asia.blackhandle.wechatrevokemsg.common.constant.RedisKeyConstant;
import asia.blackhandle.wechatrevokemsg.common.enums.RevokeProcessEnum;
import asia.blackhandle.wechatrevokemsg.domain.MessageEntity;
import com.google.gson.Gson;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.time.LocalDateTime;

/**
 * RevokeMsgService
 *
 * @author yongqi yang
 * @date 2021/11/30
 */
@Service
public class RevokeMsgService {

    static IDWorker idWorker = new IDWorker(1,1,1);
    static final Gson gson = new Gson();

    @Resource
    private StringRedisTemplate stringRedisTemplate;

    public void revokeMsg(String body) {
        String[] messageArray = body.split("\\|");
        if (messageArray.length != GlobalConstant.MESSAGE_LENGTH){
            return;
        }
        long id = idWorker.nextId();
        MessageEntity messageEntity = MessageEntity.builder()
                .wxId(messageArray[0])
                .origin(RevokeProcessEnum.WECHAT.getCode())
                .content(messageArray[1])
                .revokeTips(messageArray[2])
                .revokeTime(LocalDateTime.now())
                .id(id)
                .build();
        if (messageArray[0].contains("@chatroom")){
            messageEntity.setIsChatRoom(true);
        }
        if (messageArray[1].startsWith("<xml>")){
            messageEntity.setIsXml(true);
        }
        if (messageArray[2].contains("撤回")){
            messageEntity.setRevokeUser(messageArray[2].substring(0, messageArray[2].indexOf("撤回")));
        }else
            messageEntity.setRevokeUser("无");

//        stringRedisTemplate.opsForValue().set(RedisKeyConstant.REDIS_PREFIX + id, gson.toJson(messageEntity));
        stringRedisTemplate.opsForList().leftPush(RedisKeyConstant.REDIS_PREFIX, gson.toJson(messageEntity));
    }
}
