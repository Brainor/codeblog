package asia.blackhandle.wechatrevokemsg.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * MessageEntity
 *
 * @author yongqi yang
 * @date 2021/11/30
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder(toBuilder = true)
public class MessageEntity {

    /**
     * id
     */
    private Long id;
    /**
     * 微信id
     */
    private String wxId;
    /**
     * 消息类型
     */
    private String type;
    /**
     * 消息来源
     */
    private Integer origin;
    /**
     * 撤回提示
     */
    private String revokeTips;
    /**
     * 消息内容
     */
    private String content;
    /**
     * 是否为xml
     */
    private Boolean isXml;
    /**
     * 撤回人
     */
    private String revokeUser;
    /**
     * 是否为群聊
     */
    private Boolean isChatRoom;
    /**
     * 撤回时间
     */
    private LocalDateTime revokeTime;
}
