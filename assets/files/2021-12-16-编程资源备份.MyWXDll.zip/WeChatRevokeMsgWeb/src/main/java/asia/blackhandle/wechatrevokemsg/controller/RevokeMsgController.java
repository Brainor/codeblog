package asia.blackhandle.wechatrevokemsg.controller;

import asia.blackhandle.wechatrevokemsg.service.RevokeMsgService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * RevokeMsgController
 *
 * @author yongqi yang
 * @date 2021/11/30
 */
@RestController
public class RevokeMsgController {

    @Resource
    private RevokeMsgService revokeMsgService;

    @PostMapping("/test")
    public void revokeMsg(@RequestBody String body){
        System.out.println(body);
        if (StringUtils.isNotBlank(body)){
            revokeMsgService.revokeMsg(body);
        }
    }
}
